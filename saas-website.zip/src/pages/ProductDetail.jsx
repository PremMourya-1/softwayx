import { useParams, Link } from 'react-router-dom';
import { products } from '../data/products';

const ProductDetail = () => {
    const { id } = useParams();
    const product = products.find((p) => p.id === id);

    if (!product) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center text-center container-custom section-padding">
                <h1 className="section-title mb-4">Product Not Found</h1>
                <p className="text-gray-400 mb-8">The product you're looking for doesn't exist.</p>
                <Link to="/" className="btn-primary">
                    Back to Home
                </Link>
            </div>
        );
    }

    return (
        <main className="section-padding-top pt-24 md:pt-28">
            <div className="container-custom">
                {/* Breadcrumb */}
                <nav className="flex items-center gap-2 text-sm text-gray-500 mb-8">
                    <Link to="/" className="hover:text-white transition-colors">
                        Home
                    </Link>
                    <span>/</span>
                    <Link to="/#products" className="hover:text-white transition-colors">
                        Products
                    </Link>
                    <span>/</span>
                    <span className="text-white">{product.title}</span>
                </nav>

                {/* Hero */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
                    <div className="animate-slide-up">
                        {/* Icon + badge */}
                        <div className="flex items-center gap-4 mb-6">
                            <div
                                className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${product.color} flex items-center justify-center text-3xl shadow-glow-md`}
                            >
                                {product.icon}
                            </div>
                            <span className="badge">Software Solution</span>
                        </div>

                        <h1 className="section-title mb-4">
                            {product.title}
                        </h1>
                        <p className="text-brand-blue font-semibold text-lg mb-4">{product.tagline}</p>
                        <p className="text-gray-400 text-base leading-relaxed mb-8">
                            {product.description}
                        </p>

                        <div className="flex flex-col sm:flex-row gap-4">
                            <Link to="/register" className="btn-primary text-base px-8 py-3">
                                Get Started Free
                            </Link>
                            <Link to="/contact" className="btn-secondary text-base px-8 py-3">
                                Request Demo
                            </Link>
                        </div>
                    </div>

                    {/* Hero visual */}
                    <div
                        className={`glass rounded-2xl h-64 md:h-80 flex items-center justify-center bg-gradient-to-br ${product.color} opacity-80`}
                    >
                        <span className="text-8xl">{product.icon}</span>
                    </div>
                </div>

                {/* Features */}
                <section className="mb-20">
                    <div className="text-center mb-10">
                        <h2 className="text-2xl md:text-3xl font-bold mb-3">
                            Key <span className="gradient-text">Features</span>
                        </h2>
                        <p className="text-gray-400">Everything you need in one place.</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                        {product.features.map((feature) => (
                            <div key={feature} className="card">
                                <div className="flex items-start gap-3">
                                    <span className="mt-0.5 text-brand-blue text-lg">✓</span>
                                    <span className="text-gray-300 text-sm leading-relaxed">{feature}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

                {/* Screenshots */}
                <section className="mb-20">
                    <div className="text-center mb-10">
                        <h2 className="text-2xl md:text-3xl font-bold mb-3">
                            Product <span className="gradient-text">Screenshots</span>
                        </h2>
                        <p className="text-gray-400">A glimpse of the interface.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {product.screenshots.map((shot) => (
                            <div
                                key={shot.label}
                                className={`glass rounded-xl h-48 flex flex-col items-center justify-center bg-gradient-to-br ${shot.bg} gap-3`}
                            >
                                <span className="text-3xl">{product.icon}</span>
                                <span className="text-white text-sm font-medium">{shot.label}</span>
                            </div>
                        ))}
                    </div>
                </section>

                {/* CTA */}
                <section className="mb-16">
                    <div className="glass rounded-2xl p-8 md:p-12 text-center relative overflow-hidden">
                        <div className={`absolute inset-0 bg-gradient-to-br ${product.color} opacity-10 pointer-events-none`} />
                        <div className="relative z-10">
                            <h2 className="text-2xl md:text-3xl font-bold mb-3">
                                Start Using <span className="gradient-text">{product.title}</span> Today
                            </h2>
                            <p className="text-gray-400 mb-8 max-w-lg mx-auto">
                                Set up in minutes. No credit card required. Cancel anytime.
                            </p>
                            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                                <Link to="/register" className="btn-primary text-base px-8 py-3">
                                    Register / Get Started
                                </Link>
                                <Link to="/" className="btn-ghost text-base">
                                    ← Back to Products
                                </Link>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </main>
    );
};

export default ProductDetail;
