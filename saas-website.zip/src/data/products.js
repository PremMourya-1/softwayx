export const products = [
  {
    id: "gym-crm",
    title: "Gym CRM",
    tagline: "Manage memberships, trainers & schedules effortlessly.",
    description:
      "A full-featured CRM built for fitness businesses. Track member renewals, attendance, trainer assignments, and revenue — all in one dashboard.",
    icon: "🏋️",
    color: "from-blue-600 to-cyan-500",
    features: [
      "Member management & renewals",
      "Trainer scheduling & assignments",
      "Attendance tracking with QR check-in",
      "Revenue & analytics dashboard",
      "SMS / WhatsApp notifications",
      "Mobile-friendly interface",
    ],
    screenshots: [
      { label: "Dashboard Overview", bg: "from-blue-900/40 to-cyan-900/20" },
      { label: "Member List", bg: "from-cyan-900/40 to-blue-900/20" },
      { label: "Analytics", bg: "from-indigo-900/40 to-blue-900/20" },
    ],
  },
  {
    id: "billing-pro",
    title: "Billing Pro",
    tagline: "Invoices, payments & taxation made simple.",
    description:
      "Automate your billing workflow with smart invoicing, GST compliance, payment tracking, and one-click PDF exports. Built for Indian SMEs.",
    icon: "💳",
    color: "from-purple-600 to-pink-500",
    features: [
      "GST-compliant invoicing",
      "Online payment gateway integration",
      "Recurring billing automation",
      "Multi-currency support",
      "Real-time payment tracking",
      "Bulk PDF / Excel export",
    ],
    screenshots: [
      { label: "Invoice Builder", bg: "from-purple-900/40 to-pink-900/20" },
      { label: "Payment Dashboard", bg: "from-pink-900/40 to-purple-900/20" },
      { label: "GST Reports", bg: "from-violet-900/40 to-purple-900/20" },
    ],
  },
  {
    id: "erp-suite",
    title: "ERP Suite",
    tagline: "End-to-end business operations on one platform.",
    description:
      "A modular ERP covering inventory, HR, procurement, production, and finance. Scales from small businesses to mid-size enterprises.",
    icon: "🏢",
    color: "from-emerald-600 to-teal-500",
    features: [
      "Inventory & warehouse management",
      "HR, payroll & leave management",
      "Purchase & vendor management",
      "Production & BOM tracking",
      "Financial ledger & reporting",
      "Role-based access control",
    ],
    screenshots: [
      { label: "ERP Dashboard", bg: "from-emerald-900/40 to-teal-900/20" },
      { label: "Inventory View", bg: "from-teal-900/40 to-emerald-900/20" },
      { label: "HR Module", bg: "from-green-900/40 to-teal-900/20" },
    ],
  },
  {
    id: "school-erp",
    title: "School ERP",
    tagline: "Digital transformation for modern schools.",
    description:
      "Manage admissions, academics, fees, staff payroll, and parent communication from a single unified platform designed for K-12 schools.",
    icon: "🎓",
    color: "from-orange-500 to-yellow-500",
    features: [
      "Online admissions & fee collection",
      "Timetable & attendance automation",
      "Academic progress tracking",
      "Parent communication portal",
      "Staff payroll management",
      "Library & transport management",
    ],
    screenshots: [
      { label: "School Dashboard", bg: "from-orange-900/40 to-yellow-900/20" },
      { label: "Student Profile", bg: "from-yellow-900/40 to-orange-900/20" },
      { label: "Fee Collection", bg: "from-amber-900/40 to-orange-900/20" },
    ],
  },
  {
    id: "pos-retail",
    title: "POS & Retail",
    tagline: "Smart billing at the speed of business.",
    description:
      "A lightning-fast POS system with barcode scanning, real-time inventory sync, loyalty programs, and multi-outlet management.",
    icon: "🛒",
    color: "from-rose-600 to-red-500",
    features: [
      "Fast barcode & QR billing",
      "Real-time inventory sync",
      "Loyalty & discount management",
      "Multi-outlet & franchise support",
      "Daily sales reports",
      "Offline mode support",
    ],
    screenshots: [
      { label: "POS Terminal", bg: "from-rose-900/40 to-red-900/20" },
      { label: "Inventory Sync", bg: "from-red-900/40 to-rose-900/20" },
      { label: "Sales Report", bg: "from-pink-900/40 to-rose-900/20" },
    ],
  },
  {
    id: "hrms",
    title: "HRMS",
    tagline: "Hire, manage and retain your best talent.",
    description:
      "A comprehensive HRMS covering recruitment, onboarding, performance reviews, leave & attendance, and payroll processing with compliance.",
    icon: "👥",
    color: "from-indigo-600 to-blue-500",
    features: [
      "Recruitment & ATS pipeline",
      "Onboarding workflows",
      "Leave & attendance tracking",
      "Performance review cycles",
      "Automated payroll & payslips",
      "Compliance & statutory reports",
    ],
    screenshots: [
      { label: "HR Dashboard", bg: "from-indigo-900/40 to-blue-900/20" },
      { label: "Employee Profile", bg: "from-blue-900/40 to-indigo-900/20" },
      { label: "Payroll Module", bg: "from-violet-900/40 to-indigo-900/20" },
    ],
  },
];
