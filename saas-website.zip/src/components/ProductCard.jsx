import { useHistory } from 'react-router-dom';

const ProductCard = ({ product }) => {
    const history = useHistory();

    return (
        <div
            className="card cursor-pointer group"
            onClick={() => history.push(`/product/${product.id}`)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && history.push(`/product/${product.id}`)}
            aria-label={`View details for ${product.title}`}
        >
            {/* Icon */}
            <div
                className={`w-12 h-12 rounded-xl bg-gradient-to-br ${product.color} flex items-center justify-center text-2xl mb-4 shadow-glow-sm`}
            >
                {product.icon}
            </div>

            {/* Title */}
            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-blue-300 transition-colors">
                {product.title}
            </h3>

            {/* Tagline */}
            <p className="text-gray-400 text-sm leading-relaxed line-clamp-3">
                {product.tagline}
            </p>

            {/* Arrow */}
            <div className="mt-4 flex items-center gap-1 text-brand-blue text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                <span>Explore</span>
                <span className="translate-x-0 group-hover:translate-x-1 transition-transform">→</span>
            </div>
        </div>
    );
};

export default ProductCard;
