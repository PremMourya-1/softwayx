import { useState } from 'react';
import Input from '../components/Input';
import Button from '../components/Button';

const contactInfo = [
    { icon: '📧', label: 'Email', value: 'hello@premsoft.in' },
    { icon: '📞', label: 'Phone', value: '+91 98765 43210' },
    { icon: '🏢', label: 'Office', value: 'Bangalore, India' },
    { icon: '⏰', label: 'Hours', value: 'Mon–Fri, 9am–6pm IST' },
];

const Contact = () => {
    const [values, setValues] = useState({ name: '', email: '', subject: '', message: '' });
    const [errors, setErrors] = useState({});
    const [sent, setSent] = useState(false);

    const validate = () => {
        const e = {};
        if (!values.name.trim()) e.name = 'Name is required.';
        if (!values.email.trim()) e.email = 'Email is required.';
        else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) e.email = 'Enter a valid email.';
        if (!values.subject.trim()) e.subject = 'Subject is required.';
        if (!values.message.trim()) e.message = 'Message is required.';
        return e;
    };

    const handleChange = (field) => (e) => {
        setValues((prev) => ({ ...prev, [field]: e.target.value }));
        setErrors((prev) => ({ ...prev, [field]: '' }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const errs = validate();
        if (Object.keys(errs).length) { setErrors(errs); return; }
        setSent(true);
    };

    if (sent) {
        return (
            <div className="min-h-screen flex items-center justify-center section-padding-top pt-24">
                <div className="glass rounded-2xl p-10 text-center max-w-md w-full mx-4 animate-slide-up">
                    <div className="text-5xl mb-4">📬</div>
                    <h2 className="text-2xl font-bold text-white mb-3">Message Received!</h2>
                    <p className="text-gray-400">We'll get back to you within one business day.</p>
                </div>
            </div>
        );
    }

    return (
        <main className="section-padding-top pt-24 section-padding-bottom">
            <div className="container-custom">
                {/* Header */}
                <div className="max-w-2xl mx-auto text-center mb-14 animate-fade-in">
                    <span className="badge mb-4 inline-block">Get In Touch</span>
                    <h1 className="section-title mb-4">
                        We'd Love to <span className="gradient-text">Hear From You</span>
                    </h1>
                    <p className="text-gray-400">Reach out for demos, pricing, partnerships, or support.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                    {/* Info */}
                    <div className="space-y-4">
                        {contactInfo.map((info) => (
                            <div key={info.label} className="card flex items-start gap-4">
                                <span className="text-2xl">{info.icon}</span>
                                <div>
                                    <div className="text-gray-400 text-xs mb-0.5">{info.label}</div>
                                    <div className="text-white text-sm font-medium">{info.value}</div>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Form */}
                    <div className="lg:col-span-2">
                        <div className="glass rounded-2xl p-6 md:p-8 animate-slide-up">
                            <form onSubmit={handleSubmit} noValidate className="space-y-6">
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                    <Input
                                        label="Your Name"
                                        value={values.name}
                                        onChange={handleChange('name')}
                                        error={errors.name}
                                    />
                                    <Input
                                        label="Email Address"
                                        type="email"
                                        value={values.email}
                                        onChange={handleChange('email')}
                                        error={errors.email}
                                    />
                                </div>
                                <Input
                                    label="Subject"
                                    value={values.subject}
                                    onChange={handleChange('subject')}
                                    error={errors.subject}
                                />
                                {/* Textarea */}
                                <div className="relative">
                                    <textarea
                                        rows={5}
                                        placeholder="Message"
                                        value={values.message}
                                        onChange={handleChange('message')}
                                        className={`input-field resize-none peer ${errors.message ? 'border-red-500' : ''}`}
                                    />
                                    <label className="input-label top-3 peer-placeholder-shown:top-3 peer-focus:-top-2.5 peer-focus:text-xs peer-focus:text-brand-blue peer-focus:bg-brand-dark peer-focus:px-1 peer-[&:not(:placeholder-shown)]:-top-2.5 peer-[&:not(:placeholder-shown)]:text-xs peer-[&:not(:placeholder-shown)]:text-gray-400 peer-[&:not(:placeholder-shown)]:bg-brand-dark peer-[&:not(:placeholder-shown)]:px-1">
                                        Message
                                    </label>
                                    {errors.message && (
                                        <p className="mt-1 text-xs text-red-400">{errors.message}</p>
                                    )}
                                </div>
                                <Button type="submit" variant="primary" className="w-full py-3 text-base">
                                    Send Message
                                </Button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    );
};

export default Contact;
